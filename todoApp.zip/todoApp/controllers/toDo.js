var ToDo = require('../models/accountToDo');

 
exports.test = function (req, res) {
    res.send('Test Controller');
};

exports.toDo_create = function (req, res) {
    var toDo = new ToDo(
        {
            title: req.body.title,
            duebydate: req.body.duebydate,
            createdon: req.body.createdon,
            status: req.body.status,
            active: req.body.active,
            username: req.body.username,
            email: req.body.email,
            userid: req.body.userid
        }
    );

    toDo.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('NEW ITEM, id: '+toDo.id+' CREATED!')
    })
};

exports.toDo_details_all = function (req, res) {
    ToDo.find(req.params.id, function (err, toDo) {
        if (err) return next(err);
        res.send(toDo);
    })
};

exports.toDo_details = function (req, res) {
    ToDo.findById(req.params.id, function (err, toDo) {
        if (err) return next(err);
        res.send(toDo);
    })
};

exports.toDo_update = function (req, res) {
    ToDo.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, toDo) {
        if (err) return next(err);
        res.send('ITEM UPDATED.');
    });
};

exports.toDo_delete = function (req, res) {
    ToDo.findByIdAndRemove(req.params.id, function (err) {
        if (err) return next(err);
        res.send('ITEM DELETED');
    })
};

exports.toDo_completed = function (req, res) {
    ToDo.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, toDo) {
        if (err) return next(err);
        res.send('ITEM COMPLETED');
    });
};