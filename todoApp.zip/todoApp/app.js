var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose')
var toDo = require('./routes/accountToDo');
const accountToDo = require('./models/accountToDo');
var app = express();

var dev_db_url = 'mongodb+srv://SGadmin:1234@cluster0.yerre.mongodb.net/todoDB?retryWrites=true&w=majority';
mongoose.connect(dev_db_url), { useNewUrlParser: true, useUnifiedTopology: true,};
mongoose.Promise = global.Promise
var db = mongoose.connection;

db.on('error',console.error.bind(console,'MongoDB connection error'))

app.get('/', (req, res) => {
    res.send('HELLO WORLD')
})

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));


app.use('/todoApp', accountToDo);

app.listen(3000, () => console.log("Server started listening on port: 3000"))