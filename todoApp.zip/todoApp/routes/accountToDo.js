var express = require('express');
var router = express.Router();

 
var toDo_controller = require('../controllers/toDo');



router.get('/test', toDo_controller.test);
router.post('/create', toDo_controller.toDo_create);
router.get('/', toDo_controller.toDo_details_all);
router.get('/:id', toDo_controller.toDo_details);
router.put('/:id/update', toDo_controller.toDo_update);
router.delete('/:id/delete', toDo_controller.toDo_delete);
router.put('/:id/complete', toDo_controller.toDo_completed);


module.exports = router;