var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ToDoSchema = new Schema({
    title: {type: String, required: true,max:100},
    duebydate: {type: String, required: true,max:100},
    createdon: {type: Date, default: Date.now, required: true},
    status: {type: String, required: true, max: 100},
    active: {type: String, required: true, max: 100},
    username: {type: String, required: true, max: 100},
    email: {type: String, required: false, max: 100},
    userid: {type: String, required: true, max: 100},
});

module.exports = mongoose.model('accountToDo', ToDoSchema);